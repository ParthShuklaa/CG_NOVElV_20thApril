using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using MvcMovie.Data;
using MvcMovie.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcMovie
{
    public class Program
    {
        public static void Main(string[] args)
        {
           // CreateHostBuilder(args).Build().Run();

            //var builder = WebApplication.CreateBuilder(args);
            builder.Services.AddDbContext<MvcMovieContext>(options =>
            options.UseSqlServer(builder.Configuration.GetConnectionString("MvcMovieContext")));
            //Here we are registereing DataBase COntext with dependency injection  container in program.cs

            //for Adding Service to Conatainer
            builder.Services.AddControllerWithViews();

            var app = builder.Build();
            using (var Scope = app.Sevices.CreateScope())

            {
                var services = Scope.ServiceProvider;
                SeedData.Initialize(services);
            }
            //Confugiure the HTTP request Pipeline
            if (!app.Environment.IsDevelopement())
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpRedirection();
            app.useStaticFiles();
            app.UseRouting();
            app.useAuthorization();
            app.MapControllerRoute(
                nameof: "Default",
                pattern: "{controll= Home}/{actions = Index}/{id?;");
                
            app.Run();

        }

       


        //public static IHostBuilder CreateHostBuilder(string[] args) =>
        //    Host.CreateDefaultBuilder(args)
        //        .ConfigureWebHostDefaults(webBuilder =>
        //        {
        //            webBuilder.UseStartup<Startup>();
        //        });
        
    }
}
