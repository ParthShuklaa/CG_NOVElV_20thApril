﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MvcMovie.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcMovie.Models
{
    public class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new MvcMovieContext(
                serviceProvider.GetRequiredService<DbContextOptions<MvcMovieContext>>()))
            {
                //Look for a new Movie
                if (context.Movie.Any())
                {
                    return;//Db has Been seeded
                }
                context.Movie.AddRange(
                    new Movie
                    {
                        Title = "GostBuster", 
                        ReleaseDate = DateTime.Parse("1989-2-12"),
                        Genre = "Comedy",
                        Price = 7.99M
                    },
                     new Movie
                     {
                         Title = "GostBuster2",
                         ReleaseDate = DateTime.Parse("1921-2-12"),
                         Genre = "Comedy",
                         Price = 7.99M
                     },
                         new Movie
                         {
                             Title = "Bourne Ultimatium",
                             ReleaseDate = DateTime.Parse("1989-2-12"),
                             Genre = "Comedy",
                             Price = 7.99M
                         }
                     );
                context.SaveChanges();


            }
            
        }
    }
}
